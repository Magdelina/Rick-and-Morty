import { characters } from "./characterResponse.model";

export class UserProfileModel{
    public name: string;
    public profile: string;
    public status:string;
    public species:string;
    public location:string;
    public type:string;
    public listOfEpisodes: string;

    constructor(name:string,profile:string,status:string,species:string,location:string,type:string,listOfEpisodes:string){
        this.name = name;
        this.profile = profile;
        this.status = status;
        this.species = species;
        this.location = location;
        this.type = type;
        this.listOfEpisodes = listOfEpisodes;
    }
}