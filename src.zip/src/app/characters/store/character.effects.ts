import { Injectable } from "@angular/core";
import { Actions, createEffect, ofType } from "@ngrx/effects";
import { map, concatMap } from "rxjs";
import * as CharacterActions from './character.actions';
import { characterService } from "../character.services";

@Injectable()
export class characterEfects {
    constructor(
        private actions$: Actions,
        private characterServices: characterService
    ) { }

    getCharacters$ = createEffect(() => {
        return this.actions$.pipe(
            ofType(CharacterActions.getCharacters),
            concatMap(action =>
                this.characterServices.getCharacters().pipe(
                    map(response => {
                        return CharacterActions.getCharactersSuccess({ characters: response })
                    })
                ))
        );
    })

    // getCharacter$ = createEffect(() => {
    //     return this.actions$.pipe(
    //         ofType(CharacterActions.getCharacter(Index: String)),
    //         concatMap(this.action => 
    //             this.characterServices.getCharacter(Index:String). pipe(
    //                 map(response => {
    //                     return CharacterActions.getCharactersSuccess({character:response})
    //                 })
    //             ))
    //     );
    // })

}



