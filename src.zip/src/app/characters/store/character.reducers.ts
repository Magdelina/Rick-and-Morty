import { characterResponse } from "src/app/Models/characterResponse.model";
import { InitialState, } from "@ngrx/store/src/models";
import * as CharacterActions from './character.actions';
import { createReducer, on } from "@ngrx/store";
import { EntityState, EntityAdapter, createEntityAdapter } from "@ngrx/entity";
import { state } from "@angular/animations";


export interface CharacterState extends EntityState<characterResponse> {
    loading: boolean;
    error: string;
    charaterList: characterResponse[];
    Index: string;
}

export const adapter: EntityAdapter<characterResponse> = createEntityAdapter<characterResponse>
    ({ selectId: (characters) => characters.id });

export const initialState: CharacterState = adapter.getInitialState({
    loading: true,
    error: '',
    charaterList: [],
    Index:''
});

export const characterReducer = createReducer(
    initialState,
    on(CharacterActions.getCharacters, (state) => {
        return {
            ...state,
            loading: true,
            charaterList: []
        }
    }),
    on(CharacterActions.getCharactersSuccess, (state, { characters }) => {
        return {
            ...state,
            loading: false,
            charaterList: characters
        }
    }),
    on(CharacterActions.getCharacter, state =>{
        return {
            ...state,
            loading: true,
            charaterList:[]
        }
    }),
      
);


export const { selectAll } = adapter.getSelectors();
