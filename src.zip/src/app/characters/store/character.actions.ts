import { createAction, props } from "@ngrx/store";
import { characterResponse } from "src/app/Models/characterResponse.model";

export const GET_CHARACTERS = '[character page] get characters';
export const GET_CHARACTERS_SUCCESS = '[character page] get characters success';
export const GET_CHARACTERS_FAIL = '[characters page] get characters fail';

export const GET_CHARACTER = '[user-profile] get character';
export const GET_CHARACTER_SUCCESS = '[user-profile] get character success';
export const GET_CHARACTER_FAIL = '[user-profile page] get character fail';


export const getCharacters = createAction(GET_CHARACTERS);
export const getCharactersSuccess = createAction(GET_CHARACTERS_SUCCESS,
    props<{characters : characterResponse[]}>()
    );
export const getCharactersFail = createAction(GET_CHARACTERS_FAIL,
    props<{error:any}>()
    );
    

export const getCharacter = createAction(GET_CHARACTER,
    props<{Index: string}>()
    );
export const getCharacterSuccess = createAction(GET_CHARACTER_SUCCESS, 
    props<{Index : string,characters : characterResponse[]}>()
);
export const getCharacterFail = createAction(GET_CHARACTER_FAIL,
    props<{error:any}>()
    );





