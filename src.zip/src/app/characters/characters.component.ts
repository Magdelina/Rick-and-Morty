import { Component, OnInit } from '@angular/core';
import { characterService } from './character.services';
import { Store, select } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { characterResponse } from '../Models/characterResponse.model';
import { getAllCharacters, getAllCharactersSorted } from './store/character.selector';
import { getCharacters } from './store/character.actions';

@Component({
  selector: 'app-characters',
  templateUrl: './characters.component.html',
  styleUrls: ['./characters.component.css']
})
export class CharactersComponent implements OnInit {
  //   @Input() index: number;

  // Characters: Observable<characterResponse[]> ;
  // count: Observable<number>;
  // character : any;
  //  characters$:Observable<Character[]>;
  //  allCharacters$ = this.store.pipe(select(getAllCharacters));
  characters: characterResponse[];
  allCharacters$: Observable<characterResponse[]>;

  constructor(
    private readonly store: Store
  ) { }

  ngOnInit(): void {
    this.store.dispatch(getCharacters());
    this.allCharacters$ = this.store.select(getAllCharactersSorted);
    this.store.select(getAllCharactersSorted).subscribe((c) => {
      this.characters = c;
    console.log('\n\n\n', this.characters);
      
    })
  }



}





