import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { Character } from '../Models/character.model';
import { characterResponse } from '../Models/characterResponse.model';

@Injectable({
    providedIn: 'root'
})

export class characterService {
    constructor(private http: HttpClient) { }

    getCharacters()  {
        return this.http.get<any>("https://rickandmortyapi.com/api/character")
            .pipe(
                map((data) => {                    
                    const characters: characterResponse[] = [];
                    // data.forEach(charater => {
                    //     characters.push({ ...data[charater], id: +key });
                    // })
                    for (let key in data) {
                        characters.push({ ...data[key], id: +key });
                    }
                    return data?.results;
                })
            );
    }

    getCharacterList(index: string) {
        return this.http.get<characterResponse[]>("https://rickandmortyapi.com/api/character");
    }

    //`${this.heroesUrl}/${id}`
    getCharacter(index: string) {
        return this.http.get(`${"https://rickandmortyapi.com/api/character"}/${index}`);
    }
}

