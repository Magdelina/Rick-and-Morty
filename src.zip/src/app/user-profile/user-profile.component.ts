import { Component, OnInit,OnDestroy } from '@angular/core';
import { ActivatedRoute,  } from '@angular/router';
import { characterService } from '../characters/character.services';
import { Character } from '../Models/character.model';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit, OnDestroy{
name:string;
subscription:Subscription;
character: Character;

constructor(private route: ActivatedRoute,
            private characterServices:characterService){
}
ngOnInit() {
    let id = this.route.snapshot.paramMap.get("id");
    this.getCharacter(id);
}

getCharacter(id: string): void {
  this.subscription = this.characterServices.getCharacter(id).subscribe(character => {
    this.character = character;
    console.log(this.character)
   });

  }

  ngOnDestroy(){
 this.subscription.unsubscribe();
  }
}
